from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

OPENROUTER_KEY = "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"

@app.route("/chat", methods=["POST"])
def chat():
    messages = request.json.get("messages", [])

    response = requests.post(
        "https://openrouter.ai/api/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {OPENROUTER_KEY}",
            "Content-Type": "application/json"
        },
        json={
            "model": "openai/gpt-4o-mini",
            "messages": messages
        }
    )

    data = response.json()
    reply = data["choices"][0]["message"]["content"]

    return jsonify({"reply": reply})

app.run(host="0.0.0.0", port=10000)